# Sơn La Explorer V3

Bản nâng cấp theo yêu cầu: tìm kiếm hoạt động thật, trang chi tiết riêng cho từng địa điểm, nhiều nội dung hơn, bố cục chữ + ảnh song song, bản đồ và linh vật Gióng dùng đúng ảnh người dùng cung cấp.

## Cách dùng
- Mở `index.html`.
- Gõ từ khóa vào ô tìm kiếm: tìm theo tên, địa bàn, loại hình, hoạt động và nội dung mô tả.
- Click một kết quả/địa điểm để mở `place.html?id=...`, tức trang chi tiết riêng.
- Trong trang chi tiết có: tổng quan, lịch sử/phát triển, trải nghiệm, lịch trình, lưu ý, ảnh, tọa độ và Google Maps.
- `giong-horse.jpg` là ảnh do người dùng cung cấp.

## Dữ liệu
V3 mở rộng từ các bộ dữ liệu công khai của Cổng dữ liệu mở tỉnh Sơn La, trong đó bộ “Dữ liệu du lịch cộng đồng” cập nhật 19/04/2026 có 20 bản ghi và công bố cả tọa độ. Danh sách khu/điểm được công nhận được dùng cho các mốc công nhận cấp tỉnh/quốc gia.

## Ảnh
Ảnh trong prototype hiện là ảnh tham khảo từ các website du lịch/đơn vị truyền thông. Trước khi công bố thương mại cần kiểm tra giấy phép, bản quyền và điều khoản hotlink; nên thay bằng ảnh do bạn sở hữu hoặc được cấp phép.

## Google Maps
Bản đồ 2D dùng iframe Google Maps nên có thể mở ngay khi có Internet. Nút “Chỉ đường” mở Google Maps. Bản V3 chưa bật Google Maps 3D API để tránh đưa API key vào mã nguồn.

## Nguồn chính
- Cổng dữ liệu mở Sơn La: https://data.sonla.gov.vn/detail_data/du-lieu-du-lich-cong-dong-1529
- Danh sách khu/điểm đã được công nhận: https://data.sonla.gov.vn/detail_data/danh-sach-cac-khu-diem-du-lich-da-duoc-bo-vhttdl-va-ubnd-tinh-son-la-cong-nhan-626
- Vietnam Tourism: https://vietnam.travel/vi/things-to-do/moc-chau-your-one-stop-nature-escape
- Vietnam Tourism Tà Xùa: https://www.vietnam.travel/vi/things-to-do/ta-xua-staircase-thousand-clouds
